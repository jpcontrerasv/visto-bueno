<div class="wrap">

	<?php screen_icon(); ?> 
    
    <h2><?php echo esc_html( $title ); ?></h2>
    
    <p>There aren't much settings yet.<br />
    Blame to my coding skills and my lack of free time for that. :p</p>
    
    <form method="post" action="options.php">
    
		<?php settings_fields('guan-image-notes'); ?>
        
        <table class="form-table">
            <tr valign="top">
            	<th scope="row">Comment(s) Thumbnail</th>
                <td>
                	<fieldset>
                    	<legend class="screen-reader-text"><span>Comment(s) Thumbnail</span></legend>
						
						<?php
                        
						$sndisplaymode = array( 0 => __( 'Enable' ), 1 => __( 'Disable' ) );
						
						foreach ( $sndisplaymode as $key => $value) {
							$selected = (get_option('guan_image_notes_enable_comments_thumbnail') == $key) ? 'checked="checked"' : '';
							echo "\n\t<label><input type='radio' name='guan_image_notes_enable_comments_thumbnail' value='" . esc_attr($key) . "' $selected/> $value</label><br />";
						} ?>
                    </fieldset>
                    <span class="description">
                    	<p>If disable, the comment's will not have thumbnail to the noted images.<br />
                        If enable, all exsiting comments generated from Guan Image Notes will show up including image notes added during disable thumbnail.</p>
                    </span>
                 </td>
            </tr>
             <tr valign="top">
            	<th scope="row">Sync WordPress Comment System With Guan Image Notes</th>
                <td>
                	<fieldset>
                    	<legend class="screen-reader-text"><span>Sync WordPress Comment System With Guan Image Notes</span></legend>
						
						<?php
                        
						$sndisplaymode = array( 0 => __( 'Enable' ), 1 => __( 'Disable' ) );
						
						foreach ( $sndisplaymode as $key => $value) {
							$selected = (get_option('guan_image_notes_enable_comment_sync') == $key) ? 'checked="checked"' : '';
							echo "\n\t<label><input type='radio' name='guan_image_notes_enable_comment_sync' value='" . esc_attr($key) . "' $selected/> $value</label><br />";
						} ?>
                    </fieldset>
                    <span class="description">
                    	<p>If disable, future notes will not be synced with WordPress Commenting system.<br />
                        Old notes synced with WordPress Commenting system will still exist but when updating the notes, the comments will not be updated.</p>
                    </span>
                 </td>
            </tr>
        </table>
        
        <p class="submit"><input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" /></p>
        
    </form>

	<h3>Uninstall</h3>
    <p>This plugin add tables into your WordPress database.<br />
    If you don't use this plugin anymore, it's more likely you might want to remove those tables.</p>
    <p>Warning: Once deleted, there are no ways for you to retrieve those image notes back.</p>
    <p>After you delete the database, then you can deactivate the plugin and delete it.</p>
    
    <?php $plugindir = '/wp-content/plugins/'.dirname(plugin_basename(__FILE__)); ?>
    
    <form method="post" action="<?php bloginfo('url'); ?>/wp-content/plugins/guan-image-notes/guan-image-notes-uninstall.php">
    	<p class="submit"><input type="submit" class="button-primary" value="Uninstall Now" /></p>
    </form>
        
</div>