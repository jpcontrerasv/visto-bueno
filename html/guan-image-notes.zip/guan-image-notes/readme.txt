=== Guan Image Notes ===
Contributors: Pangeran Wiguan
Donate Link: http://pangeran.org/guan-image-notes/
Tags: comment,comments,image,images,note,annotation,image annotation,facebook,flicrk,dannychoo,wiguan,pangeran, image comment
Requires at least: 2.5
Tested up to: 3.0.3
Stable tag: 2.0

Image tagging system sync with WordPress comment system. Or also known as image notes, or image annotation.

== Description ==

This plugin allows you and your visitors to add comment as textual annotations to images by select a region of the image and then attach a textual description, the concept of annotating images with user comments.
The text is intergrated with WordPress comment system.
Integration with [JQuery Image Annotation from Chris](http://www.flipbit.co.uk/jquery-image-annotation.html) with [PHP support from GitHub](http://github.com/stas/jquery-image-annotate-php-fork).
Modified from [Demon Image Annotation version 1.0](http://www.superwhite.cc/demon/image-annotation-plugin).
Icons from [Fam Fam Fam](http://www.famfamfam.com/lab/icons/silk/)

Features:

1. Ability to add notes to your uploaded pictures.
2. Show notes on single page, front page, archive page and etc.
3. Notes synced with WordPress commenting system but there's option to turn it off.
4. Gravatar in the notes.
5. Commentator's name in the notes.
6. Image thumbnail appear at comment area, but there's option to turn it off.
7. No hard coding required.
8. Admin page.
9. Remove all database if you wish to not using the plugin anymore.

== Installation ==

1. Put the plugin folder into [wordpress_dir]/wp-content/plugins/
2. Go into the WordPress admin interface and activate the plugin
3. Upload and then insert the image using the WordPress editor.
4. Complete usage instructions are available here. [Guan Image Notes](http://pangeran.org/guan-image-notes/)

== Frequently Asked Questions ==

Future Development:

1. Add option at WordPress insert image UI to choose to enable or disable image notes for that particular pictures.
2. Add option at WordPress post editor to enable or disable image notes for the entire post.
3. Add option at Guan Image Notes Settings page (We need admin page then) to allow user level interaction with the image notes.

Reported Bugs:

1. Resize image and crop them. (Never encounter them myself but reported.)
2. Authors user level does not input the id attribute.
3. After you edit a note the avatar changes to the default avatar. (Very well known issue)
4. Some images do not load the notes. (Very well known issue.)

Please report any bugs you encounter.

Thanks.

Pangeran Wiguan

== Screenshots ==

1. Demonstration of Guan Image Notes.
2. Demonstration of Guan Image Notes 2.
3. Demonstration of Guan Image Notes 3.
4. Demonstration of Guan Image Notes 4.
5. Demonstration of Guan Image Notes 5.
6. Demonstration of Guan Image Notes 6.

== Changelog ==

= 2.0 =
* More neat styling.
* Capture authors URL for non registered user who leave note(s) on the image(s).
* Add Note button will not open link for hyperlinked images.
* Add option page which enable user to disable or enable noted image thumbnail at comment area.
* Add option page which enable user to disable or enable WordPress commenting system to sync with Guan Image Notes.
* Extend character limits for image note(s).
* Add option page which enable user to wipe all databases created by Guan Image Notes.
* Change position of the Add Note button to be on top of the image so it won't interfere WordPress caption styling.
* Bug fix: Now we can resize the note region in Internet Explorer. (Tested with IE8).

= 1.1  =
* Just small css fix for more visible notes region.(Everybody shout that too me.)

= 1.0   =
* Modified from Demon Image Annotation version 1.0
* Add image thumbnail in comment area by default.
* Add author gravatar on notes.
* Show notification to ask user go to single page on the image if not on single page such as home and archives.
* Still showing notes on all other pages beside single page but not able to add or edit them.
* Beautiful rounded border. Supported Browser: Google Chrome Firefox, Opera, Safarai and IE9.
* Solve the issue of plugin not working if the database prefix is not `wp_`.

 == Upgrade Notice ==
 
= 2.0 =
* Hello, I manage to update this plugin with the following features and bug fixed.
* More neat styling.
* Capture authors URL for non registered user who leave note(s) on the image(s).
* Add Note button will not open link for hyperlinked images.
* Add option page which enable user to disable or enable noted image thumbnail at comment area.
* Add option page which enable user to disable or enable WordPress commenting system to sync with Guan Image Notes.
* Extend character limits for image note(s).
* Add option page which enable user to wipe all databases created by Guan Image Notes.
* Change position of the Add Note button to be on top of the image so it won't interfere WordPress caption styling.
* Bug fix: Now we can resize the note region in Internet Explorer. (Tested with IE8).
 
 = 1.1 =
*Just small css fix for more visible notes region.(Everybody shout that too me.)
 
 = 1.0 =
* Modified from Demon Image Annotation version 1.0
* Add image thumbnail in comment area by default.
* Add author gravatar on notes.
* Show notification to ask user go to single page on the image if not on single page such as home and archives.
* Still showing notes on all other pages beside single page but not able to add or edit them.
* Beautiful rounded border. Supported Browser: Google Chrome Firefox, Opera, Safarai and IE9.
* Solve the issue of plugin not working if the database prefix is not `wp_`.